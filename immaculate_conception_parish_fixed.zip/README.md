# Immaculate Conception Parish — website source files

This package contains a small, diagnostic-friendly Supabase website:
- `index.html`: login page
- `js/config.js`: project URL and publishable-key configuration
- `js/auth.js`: Supabase password login and profile check
- `dashboard.html`: dashboard page
- `js/dashboard.js`: loads the signed-in user's profile and parishioner list, with visible timeout/error messages
- `css/styles.css`: responsive styling
- `database/diagnostics.sql`: safe read-only checks
- `database/schema_reference.sql`: non-destructive baseline reference only

## Important before uploading
1. In `js/config.js`, replace `REPLACE_WITH_YOUR_CURRENT_SB_PUBLISHABLE_KEY` with the project's current **publishable** key (`sb_publishable_...`).
2. Never put an `sb_secret_...` or `service_role` key in browser code.
3. Upload the files to the root of your GitHub Pages repository, keeping the `js`, `css`, and `database` folders.
4. Keep the same Supabase project URL that contains your current parish data.
5. Do not run destructive SQL or replace existing RLS policies. Your current database already contains tables and policies.
6. This is a starter/replacement frontend, not a verified export of every existing feature/table in your live project. It currently provides login, profile verification, parishioner listing/search, refresh and logout. Other parish modules (dues, tithes, offerings, sacraments, organizations, announcements, photo uploads, role-based editing) need to be integrated against the exact live table columns and policies before being considered complete.

## Changes in this version
- `js/config.js` now explains exactly what is wrong with the key (missing, secret key, wrong format) and rejects unsafe keys.
- Login page sends already-signed-in users straight to the dashboard.
- Dashboard shows Total / Active / Male / Female counts again (Male/Female need a `gender` or `sex` column; otherwise they show "—").
- Optional `database/add_missing_policies.sql` adds read policies only if they are missing.

## If the dashboard still cannot load
The dashboard will now display an explicit error rather than spin forever. Share only the error text, not passwords, access tokens, or secret keys.
