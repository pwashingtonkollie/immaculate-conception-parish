-- SCHEMA REFERENCE / OPTIONAL BASELINE ONLY
-- This is intentionally non-destructive: CREATE TABLE IF NOT EXISTS will not
-- change existing tables. Your live parishioners table already exists, so
-- inspect its columns before applying any schema changes.
-- Do not run DROP TABLE or replace existing policies to troubleshoot loading.

CREATE TABLE IF NOT EXISTS public.user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role text NOT NULL CHECK (role IN (
    'main_administrator', 'parish_priest', 'financial_admin',
    'financial_admin_2', 'data_entry'
  )),
  is_active boolean NOT NULL DEFAULT true
);

-- Minimal reference only. Existing table columns may be more extensive.
-- This statement creates the table only if it does not already exist.
CREATE TABLE IF NOT EXISTS public.parishioners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text,
  last_name text,
  status text DEFAULT 'Active'
);

-- Security policies are intentionally NOT recreated here because the live
-- project already has policies. Review database/diagnostics.sql first.
