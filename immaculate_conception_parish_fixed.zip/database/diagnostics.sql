-- Safe, read-only diagnostics for the existing Supabase project.
-- Run these in Supabase SQL Editor. These statements do not modify data.

-- 1. Confirm the two core tables and RLS setting.
SELECT tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
  AND tablename IN ('user_profiles', 'parishioners');

-- 2. Confirm active profiles (omit the id column when sharing results publicly).
SELECT full_name, role, is_active, id
FROM public.user_profiles
ORDER BY full_name;

-- 3. Confirm the parishioner table's actual columns before changing app code.
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'parishioners'
ORDER BY ordinal_position;

-- 4. Inspect current policies. Do not drop or replace policies without review.
SELECT tablename, policyname, cmd, roles, qual, with_check
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('user_profiles', 'parishioners')
ORDER BY tablename, cmd;
