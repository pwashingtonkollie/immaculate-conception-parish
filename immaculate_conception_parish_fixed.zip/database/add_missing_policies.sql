-- OPTIONAL and ADDITIVE. Run only if login says "profile could not be loaded"
-- or the parishioner list is empty/blocked, AND diagnostics.sql (query 4)
-- shows no equivalent policy. Creates policies only if the name is absent;
-- does not drop or alter anything.

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public'
      AND tablename='user_profiles' AND policyname='staff_read_own_profile') THEN
    CREATE POLICY staff_read_own_profile ON public.user_profiles
      FOR SELECT TO authenticated USING (auth.uid() = id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public'
      AND tablename='parishioners' AND policyname='active_staff_read_parishioners') THEN
    CREATE POLICY active_staff_read_parishioners ON public.parishioners
      FOR SELECT TO authenticated USING (
        EXISTS (SELECT 1 FROM public.user_profiles up
                WHERE up.id = auth.uid() AND up.is_active)
      );
  END IF;
END $$;
